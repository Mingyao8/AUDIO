let isListening = false;
let mediaRecorder = null;
let audioChunks = [];
let currentMode = 'general';
globalThis.startButton = null;

// 取得 CSRF Token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        document.cookie.split(';').forEach(cookie => {
            const trimmed = cookie.trim();
            if (trimmed.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(trimmed.slice(name.length + 1));
            }
        });
    }
    return cookieValue;
}

// 上傳錄音給 /process_audio/（Whisper）
async function transcribeAudio(blob) {
    const formData = new FormData();
    formData.append('audio', blob, 'speech.wav');

    const res = await fetch('/process_audio/', {
        method: 'POST',
        headers: { 'X-CSRFToken': getCookie('csrftoken') },
        body: formData
    });
    if (!res.ok) throw new Error(`轉寫失敗（${res.status}）`);
    return res.json();  // { transcription: "..." }
}

// 傳送轉寫結果到後端處理
async function sendCommand(text, mode) {
    const res = await fetch('/process_general_command/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({ transcription: text, command_mode: mode })
    });
    if (!res.ok) throw new Error(`命令處理失敗（${res.status}）`);
    return res.json();  // 可能包含 redirect_url
}

// 開始錄音
function startRecording() {
    if (mediaRecorder && mediaRecorder.state === 'inactive') {
        mediaRecorder.start();
    }
}

// 初始化錄音器
async function initRecorder() {
    if (mediaRecorder) return;
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = e => {
            if (e.data && e.data.size > 0) audioChunks.push(e.data);
        };

        mediaRecorder.onstart = () => {
            audioChunks = [];
            document.getElementById("voice-status").innerText = `狀態：${currentMode} 階段，錄音中…`;
            setTimeout(() => {
                if (mediaRecorder.state === "recording") mediaRecorder.stop();
            }, 5000);
        };

        mediaRecorder.onstop = async () => {
            document.getElementById("voice-status").innerText = "狀態：錄音結束，處理中…";
            const blob = new Blob(audioChunks, { type: 'audio/wav' });
            try {
                const whisperData = await transcribeAudio(blob);
                const text = whisperData.transcription;
                document.getElementById("voice-status").innerText = `轉寫文字：${text}`;

                const cmdData = await sendCommand(text, currentMode);

                // --- 處理不同對話階段 ---
                if (currentMode === 'general') {
                    const type = cmdData.command_type;
                    if (type === 'select_file') {
                        currentMode = 'select_file';
                        document.getElementById("voice-status").innerText = "請說出要選擇的檔案編號，如：一號檔案";
                        if (isListening) setTimeout(startRecording, 500);
                    } else if (type === 'list_files') {
                        document.getElementById("voice-status").innerText = "檔案列表：請查看介面上的檔案清單";
                        resetConversation();
                    } else if (type === 'input_instruction') {
                        currentMode = 'input_instruction';
                        document.getElementById("voice-status").innerText = "請說出修改指令內容";
                        if (isListening) setTimeout(startRecording, 500);
                    } else if (type === 'execute') {
                        currentMode = 'execute';
                        document.getElementById("voice-status").innerText = "準備執行程式碼…";
                        if (isListening) setTimeout(startRecording, 500);
                    } else {
                        document.getElementById("voice-status").innerText = "指令無法辨識，請重新開始";
                        resetConversation();
                    }
                } else if (currentMode === 'select_file') {
                    if (cmdData.success) {
                        document.getElementById("voice-status").innerText = cmdData.message;
                        if (cmdData.redirect_url) {
                            window.location.href = cmdData.redirect_url;  // ⬅️ 自動跳轉
                        } else {
                            currentMode = 'input_instruction';
                            document.getElementById("voice-status").innerText += "，請說出修改指令內容";
                            if (isListening) setTimeout(startRecording, 500);
                        }
                    } else {
                        document.getElementById("voice-status").innerText = cmdData.message;
                        resetConversation();
                    }
                } else if (currentMode === 'input_instruction') {
                    if (cmdData.success) {
                        document.getElementById("voice-status").innerText = "AI 已產生修改後的 G-code";
                        currentMode = 'execute';
                        document.getElementById("voice-status").innerText += "，開始執行程式碼";
                        if (isListening) setTimeout(startRecording, 500);
                    } else {
                        document.getElementById("voice-status").innerText = cmdData.message;
                        resetConversation();
                    }
                } else if (currentMode === 'execute') {
                    if (cmdData.success) {
                        document.getElementById("voice-status").innerText = `執行結果：${cmdData.execution_result}`;
                    } else {
                        document.getElementById("voice-status").innerText = cmdData.message;
                    }
                    resetConversation();
                }

            } catch (err) {
                console.error(err);
                document.getElementById("voice-status").innerText = `❌ 錯誤：${err.message}`;
                resetConversation();
            }
        };

    } catch (err) {
        console.error("無法取得麥克風：", err);
        document.getElementById("voice-status").innerText = "❌ 無法取得麥克風";
        resetConversation();
    }
}

// 重設對話狀態
function resetConversation() {
    isListening = false;
    currentMode = 'general';
    if (globalThis.startButton) {
        globalThis.startButton.innerText = '🎤 開始語音對話';
    }
}

// 初始化按鈕
document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("start-conversation");
    globalThis.startButton = btn;
    btn.addEventListener("click", async () => {
        if (!isListening) {
            isListening = true;
            btn.innerText = "🛑 停止對話";
            document.getElementById("voice-status").innerText = "狀態：準備錄音…";
            await initRecorder();
            startRecording();
        } else {
            resetConversation();
            if (mediaRecorder && mediaRecorder.state === "recording") mediaRecorder.stop();
            document.getElementById("voice-status").innerText = "狀態：已停止";
        }
    });
});
