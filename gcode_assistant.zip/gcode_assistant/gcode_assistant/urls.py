from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from gcode_app import views

urlpatterns = [
    path('', views.index, name='index'),
    path('file/<int:file_id>/', views.file_detail, name='file_detail'),
    path('process_audio/', views.process_audio, name='process_audio'),
    path('process_general_command/', views.process_general_command, name='process_general_command'),]

# 如果有上傳檔案，記得加入 static 設定
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
