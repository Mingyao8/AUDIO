from django.apps import AppConfig


class GcodeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gcode_app'
