import json
import re
import tempfile
import requests
import whisper

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from django.shortcuts import render
from .models import GcodeFile, ModifiedFile
from django.urls import reverse

# 初始化 Whisper 模型
whisper_model = whisper.load_model("base")

# DeepSeek 設定
DEEPSEEK_API_KEY = "sk-600df456302d43159bac831b051a4432"
BASE_URL = "https://api.deepseek.com"
DEEPSEEK_CHAT_URL = f"{BASE_URL}/v1/chat/completions"

original = []  # 全局變數暫存 G-code 原始內容

def index(request):
    files = GcodeFile.objects.all()
    return render(request, 'index.html', {'files': files})

def file_detail(request, file_id):
    gcode_file = GcodeFile.objects.get(id=file_id)
    return render(request, 'file_detail.html', {'file': gcode_file})

def save_temp_audio(uploaded_file):
    with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp:
        for chunk in uploaded_file.chunks():
            tmp.write(chunk)
        return tmp.name

def parse_number(ch_str: str) -> int:
    m = re.search(r'\d+', ch_str)
    if m:
        return int(m.group())
    cn_map = {'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10}
    for cn, num in cn_map.items():
        if cn in ch_str:
            return num
    raise ValueError('無法解析數字')

def ai_modify_gcode(file_id: int, instruction: str) -> str:
    gfile = GcodeFile.objects.get(pk=file_id)
    global original
    original = gfile.file_content.splitlines(keepends=True)

    prompt = (
        f"以下是部分 G-code 內容：\n{''.join(original)}\n\n"
        f"請根據這段自然語言指令「{instruction}」寫一段 Python 程式碼，並且不要有其他註解!"
        f"修改 `lines` 這個 list（每行是一行 G-code）。\n"
        f"非常重要：你必須保留每一行G-code的換行符號('\\n')！"
    )

    payload = {
        'model': 'deepseek-chat',
        'messages': [
            {'role': 'system', 'content': '你是一個 G-code 處理專家，請輸出可直接 exec() 的 Python 程式碼'},
            {'role': 'user', 'content': prompt}
        ]
    }
    headers = {
        'Authorization': f'Bearer {DEEPSEEK_API_KEY}',
        'Content-Type': 'application/json'
    }
    response = requests.post(DEEPSEEK_CHAT_URL, headers=headers, json=payload)
    response.raise_for_status()
    code = response.json()['choices'][0]['message']['content']

    ModifiedFile.objects.create(
        original_file=gfile,
        instruction=instruction,
        modified_content='',  # 程式碼尚未執行，無法知道結果
        generated_code=code
    )

    return code

def ensure_newlines(lines):
    return [line if line.endswith('\n') else line + '\n' for line in lines]

@csrf_exempt
def process_audio(request):
    if request.method != 'POST':
        return JsonResponse({'success': False, 'message': '僅支援 POST'}, status=405)

    audio_file = request.FILES.get('audio')
    if not audio_file:
        return JsonResponse({'success': False, 'message': '未收到音檔'}, status=400)

    temp_path = save_temp_audio(audio_file)
    result = whisper_model.transcribe(temp_path, language='zh')
    transcription = result.get('text', '')
    return JsonResponse({'success': True, 'transcription': transcription})

@csrf_exempt
def process_general_command(request):
    if request.method != 'POST':
        return JsonResponse({'success': False, 'message': '僅支援 POST'}, status=405)

    try:
        payload = json.loads(request.body.decode('utf-8'))
    except json.JSONDecodeError:
        return JsonResponse({'success': False, 'message': '無效的 JSON'}, status=400)

    transcription = payload.get('transcription', '')
    mode = payload.get('command_mode', 'general')

    if mode == 'general':
        cmd = 'unknown'
        if re.search(r'選擇|載入|打開|開啟|檔案', transcription): cmd = 'select_file'
        elif re.search(r'列表|清單|檔案列表|顯示檔案|有哪些', transcription): cmd = 'list_files'
        elif re.search(r'輸入|指令|修改|改變', transcription): cmd = 'input_instruction'
        elif re.search(r'執行|處理|開始|運行|進行', transcription): cmd = 'execute'
        elif re.search(r'幫助|說明|怎麼用|如何使用', transcription): cmd = 'help'
        return JsonResponse({'success': True, 'command_type': cmd})

    if mode == 'select_file':
        try:
            num = parse_number(transcription)
            gfile = GcodeFile.objects.get(file_number=num)
        except (ValueError, GcodeFile.DoesNotExist):
            return JsonResponse({'success': False, 'message': '無效的檔案編號'}, status=400)

        request.session['selected_file_id'] = gfile.id
        detail_url = reverse('file_detail', args=[gfile.id])
        return JsonResponse({
            'success': True,
            'message': f'已選擇 {num} 號檔案',
            'redirect_url': detail_url
        })

    if mode == 'input_instruction':
        file_id = request.session.get('selected_file_id')
        if not file_id:
            return JsonResponse({'success': False, 'message': '尚未選擇檔案'}, status=400)
        generated = ai_modify_gcode(file_id, transcription)
        request.session['last_generated_code'] = generated
        return JsonResponse({'success': True, 'generated_code': generated})

    if mode == 'execute':
        code = request.session.get('last_generated_code', transcription)
        print(code)
        local_vars = {"lines": original.copy()}
        try:
            exec(code, {}, local_vars)
            result_lines = local_vars.get("lines", original)
            return JsonResponse({'success': True, 'execution_result': ''.join(ensure_newlines(result_lines))})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'message': '不支援的 command_mode'}, status=400)
