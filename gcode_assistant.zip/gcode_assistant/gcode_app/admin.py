from django.contrib import admin
from .models import GcodeFile, ModifiedFile

@admin.register(GcodeFile)
class GcodeFileAdmin(admin.ModelAdmin):
    list_display = ('file_number', 'file_name', 'upload_date')
    search_fields = ('file_name',)
    ordering = ('file_number',)

@admin.register(ModifiedFile)
class ModifiedFileAdmin(admin.ModelAdmin):
    list_display = ('original_file', 'instruction', 'created_date')
    list_filter = ('created_date',)
    search_fields = ('instruction',)