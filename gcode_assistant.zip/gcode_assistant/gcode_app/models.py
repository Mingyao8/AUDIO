from django.db import models
from django.contrib.auth.models import User

class GcodeFile(models.Model):
    file_number = models.IntegerField(unique=True)
    file_name = models.CharField(max_length=255)
    file_content = models.TextField()
    upload_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.file_number}. {self.file_name}"

class ModifiedFile(models.Model):
    original_file = models.ForeignKey(GcodeFile, on_delete=models.CASCADE)
    instruction = models.TextField()
    modified_content = models.TextField()
    generated_code = models.TextField()
    created_date = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Modified {self.original_file.file_name}"
    

class VoiceSession(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    state = models.CharField(max_length=50, default='waiting_for_command')
    selected_file_id = models.IntegerField(null=True, blank=True)
    instruction = models.TextField(null=True, blank=True)
    modified_file_id = models.IntegerField(null=True, blank=True)
    
    def __str__(self):
        return f"Session {self.id} - {self.state}"